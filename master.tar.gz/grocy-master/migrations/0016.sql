ALTER TABLE shopping_list RENAME TO shopping_list_old
