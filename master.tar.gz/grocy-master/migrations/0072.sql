ALTER TABLE userfields
ADD config TEXT;
