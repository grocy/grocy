DELETE FROM locations
WHERE name = 'DefaultLocation';

DELETE FROM quantity_units
WHERE name = 'DefaultQuantityUnit';

DELETE FROM products
WHERE name = 'DefaultProduct1';

DELETE FROM products
WHERE name = 'DefaultProduct2';
