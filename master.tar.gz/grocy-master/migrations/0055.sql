ALTER TABLE stock_log
ADD recipe_id INTEGER;
