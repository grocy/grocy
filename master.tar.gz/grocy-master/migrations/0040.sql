ALTER TABLE products
ADD picture_file_name TEXT;
