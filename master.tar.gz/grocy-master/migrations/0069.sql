ALTER TABLE chores
ADD track_date_only TINYINT DEFAULT 0;
