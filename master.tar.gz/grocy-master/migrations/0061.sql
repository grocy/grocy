ALTER TABLE products
ADD not_check_stock_fulfillment_for_recipes TINYINT DEFAULT 0;
