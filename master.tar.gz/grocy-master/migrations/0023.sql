DELETE FROM sessions
