ALTER TABLE shopping_list
ADD done INT DEFAULT 0;
