ALTER TABLE api_keys
ADD key_type TEXT NOT NULL DEFAULT 'default';
