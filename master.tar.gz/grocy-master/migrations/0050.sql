ALTER TABLE recipes
ADD picture_file_name TEXT;
