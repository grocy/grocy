ALTER TABLE quantity_units
ADD plural_forms TEXT;
