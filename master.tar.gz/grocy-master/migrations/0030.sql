ALTER TABLE quantity_units
ADD name_plural TEXT;
