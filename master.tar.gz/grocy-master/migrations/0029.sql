ALTER TABLE stock
ADD price DECIMAL(15, 2);

ALTER TABLE stock_log
ADD price DECIMAL(15, 2);
