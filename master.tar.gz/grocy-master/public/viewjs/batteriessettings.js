﻿$("#batteries_due_soon_days").val(Grocy.UserSettings.batteries_due_soon_days);
