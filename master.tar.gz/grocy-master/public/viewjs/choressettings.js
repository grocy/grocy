﻿$("#chores_due_soon_days").val(Grocy.UserSettings.chores_due_soon_days);
